/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

/**
 *
 * @author dell
 */
public class Hall {
    private int seats_front;
    private int seats_middle;
    private int seats_back;
    

    public Hall(int seats_front, int seats_middle, int seats_back) {
       this.seats_front = seats_front;
        this.seats_middle = seats_middle;
        this.seats_back = seats_back;
        
    }


    public int getSeats_front() {
        return seats_front;
    }

    public void setSeats_front(int seats_front) {
        this.seats_front = seats_front;
    }

    public int getSeats_middle() {
        return seats_middle;
    }

    public void setSeats_middle(int seats_middle) {
        this.seats_middle = seats_middle;
    }

    public int getSeats_back() {
        return seats_back;
    }

    public void setSeats_back(int seats_back) {
        this.seats_back = seats_back;
    }

    
}
