/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;

/**
 *
 * @author dell
 */
public class BookingDB {
    private static ArrayList<Booking> booklist = new ArrayList<Booking>();
    
    private static File file=new File("d:/Booking.txt");
    private static BufferedWriter writer1;
    private static BufferedReader reader1;
   
    
    static{
        try{
            reader1=new BufferedReader(new FileReader(file));
            writer1= new BufferedWriter(new FileWriter(file,true));
             
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
       public BookingDB(){
        try{
           while(reader1.ready()){
               String name=reader1.readLine();
               String mname=reader1.readLine();
               int cht=Integer.parseInt(reader1.readLine());
              String adt=reader1.readLine(); 
               int bill=Integer.parseInt(reader1.readLine());
               String seats=reader1.readLine(); 
               String time=reader1.readLine();
               String date=reader1.readLine();
               String snack=reader1.readLine();
               String drink=reader1.readLine();
               String deal=reader1.readLine();
               String pack=reader1.readLine();
               
               Booking b =new Booking(name,mname,cht,adt,bill,seats,time,Date.valueOf(date),snack,drink,deal,pack);
              booklist.add(b);
           } 
        }catch(IOException e){
            e.printStackTrace();
        }
    }
      
        
       
  
     public void BookTrip(Booking t){
             booklist.add(t);
              try{
                 writer1.write(t.getUsername());
                 writer1.newLine();
                 writer1.write(t.getMovie_name());
                 writer1.newLine();
                 writer1.write(t.getChildtickets());
                 writer1.newLine();
                 writer1.write(""+t.getAdultticket());
                 writer1.newLine();
                 writer1.write(t.getBill());
                 writer1.newLine();
                 writer1.write(t.getHall_name());
                 writer1.newLine();
                 writer1.write(t.getTime());
                 writer1.newLine();
                 writer1.write(""+t.getDate());
                 writer1.newLine();
                 writer1.write(t.getSnack());
                 writer1.newLine();
                 writer1.write(t.getDrink());
                 writer1.newLine();
                 writer1.write(t.getDeal());
                 writer1.newLine();
                   writer1.write(t.getPackage());
                 writer1.newLine();
                 writer1.flush();
             }catch(IOException ee){
                 ee.printStackTrace();
            }
    }
    public void addBooking(Booking b){
        booklist.add(b);
    }
    
     public ArrayList<Booking>getBookings(){
        return booklist;
    }
    

}
