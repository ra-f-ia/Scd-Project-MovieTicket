/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

/**
 *
 * @author dell
 */
public class Deals {
   private String name; 
   private String drink;
   private String snack;
   private int discount;
   private int price;

    public Deals(String name, String drink, String snack, int discount, int price) {
        this.name = name;
        this.drink = drink;
        this.snack = snack;
        this.discount = discount;
        this.price = price;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
 
    public String getDrink() {
        return drink;
    }

    public void setDrink(String drink) {
        this.drink = drink;
    }

    public String getSnack() {
        return snack;
    }

    public void setSnack(String snack) {
        this.snack = snack;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

   
   
/*  public int calculateDrinkPrice(){
       int price=0;
      // String drink = this.drink.toLowerCase();
       switch(drink){
           case "Pepsi":
               price = price+cmsdbWR.readItem8().getPepsi_cost();
            break;   
           case "Cocacola":
               price = price+cmsdbWR.readItem8().getCocacola_cost();
           break;
           case "Fanta":
               price = price+cmsdbWR.readItem8().getFanta_cost();
           break;
        }
       System.out.println(price);
       return price;
   }
     public int calculateSnackPrice(){
       int price=0;
     //  String snack = this.snack.toLowerCase();
       switch(snack){
           case "Popcorn":
               price = price+cmsdbWR.readItem8().getPopcorn_cost();
       break;
           case "Burger":
               price = price+cmsdbWR.readItem8().getBurger_cost();
        break;
           case "Fries":
               price = price+cmsdbWR.readItem8().getFries_cost();
   }
       System.out.println(price);
      return price;
   }
public int calculatePrice(){
    int price=0;
    price=price+calculateSnackPrice()+calculateDrinkPrice();
    System.out.println(price);
    return price;
}
*/

    @Override
    public String toString() {
        return snack.substring(0,1).toUpperCase()+snack.substring(1) + "+" +drink.substring(0,1).toUpperCase()+drink.substring(1);
    }
   
}
