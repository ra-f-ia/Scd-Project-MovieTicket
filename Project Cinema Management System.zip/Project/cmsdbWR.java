/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Date;
import java.util.ArrayList;

/**
 *
 * @author dell
 */
public class cmsdbWR {
              //Creating files programatically\\
    private static File cosFile1 = new File("d:/MovieProject.txt");
    private static File cosFile2 = new File("d:/UserProject.txt");
    private static File cosFile4 = new File("d:/HallProject.txt");
    private static File cosFile5 = new File("d:/PackageProject.txt");
   // private static File cosFile6 = new File("d:/AdminProject.txt");
    private static File cosFile7 = new File("d:/DealProject.txt");
     private static File cosFile9 = new File("d:/SnackProject.txt");
     private static File cosFile10 = new File("d:/DrinkProject.txt");
     private static File cosFile11 = new File("d:/MovieRecordProject.txt");
     private static File cosFile12 = new File("d:/FoodRecordProject.txt");
     private static File cosFile13 = new File("d:/DealsRecordProject.txt");
     private static File cosFile14 = new File("d:/SeatsRecordProject.txt");
     private static File cosFile15 = new File("d:/BookingRecordProject.txt");
   
   //private static File cosFile8 = new File("d:/PricesProject.txt");
    // private static ArrayList<Price> price = new ArrayList<Price>();
    
              //Creating Buffered writers\\
    private static BufferedWriter w1;
    private static BufferedWriter w2;
    private static BufferedWriter w4;
    private static BufferedWriter w5;
    private static BufferedWriter w6;
    private static BufferedWriter w7;
    private static BufferedWriter w8;
    private static BufferedWriter w9;
    private static BufferedWriter w10;
    private static BufferedWriter w11;
    private static BufferedWriter w12;
    private static BufferedWriter w13;
    private static BufferedWriter w14;
    private static BufferedWriter w15;
    
              //Cretaing Buffered readers\\
    private static BufferedReader r1;
    private static BufferedReader r2;
    private static BufferedReader r4;
    private static BufferedReader r5;
    private static BufferedReader r6;
    private static BufferedReader r7;
    private static BufferedReader r8;
    private static BufferedReader r9;   
    private static BufferedReader r10;
    private static BufferedReader r11;
    private static BufferedReader r12;
    private static BufferedReader r13;
    private static BufferedReader r14;
    private static BufferedReader r15;
    
    
              //Creating references\\
     static{
       try{
           w1 = new BufferedWriter(new FileWriter(cosFile1, true));
           w2 = new BufferedWriter(new FileWriter(cosFile2, true));
           w4 = new BufferedWriter(new FileWriter(cosFile4, true));
           w5 = new BufferedWriter(new FileWriter(cosFile5, true));
         //  w6 = new BufferedWriter(new FileWriter(cosFile6, true));
           w7 = new BufferedWriter(new FileWriter(cosFile7,true));
          // w8 =new BufferedWriter(new FileWriter(cosFile8,true));
           w9 = new BufferedWriter(new FileWriter(cosFile9, true));
           w10 = new BufferedWriter(new FileWriter(cosFile10, true));
           w11 = new BufferedWriter(new FileWriter(cosFile11, true));
           w12 = new BufferedWriter(new FileWriter(cosFile12, true));
           w13 = new BufferedWriter(new FileWriter(cosFile13, true));
           w14 = new BufferedWriter(new FileWriter(cosFile14, true));
           w15 = new BufferedWriter(new FileWriter(cosFile15, true));
          r1 = new BufferedReader(new FileReader(cosFile1));
           r2= new BufferedReader(new FileReader(cosFile2));
           r4 = new BufferedReader(new FileReader(cosFile4));
           r5 = new BufferedReader(new FileReader(cosFile5));
         //  r6 = new BufferedReader(new FileReader(cosFile6));
           r7 = new BufferedReader(new FileReader(cosFile7));
           r9= new BufferedReader(new FileReader(cosFile9));
           r10 = new BufferedReader(new FileReader(cosFile10));
            r11 = new BufferedReader(new FileReader(cosFile11));
             r12 = new BufferedReader(new FileReader(cosFile12)); 
             r13 = new BufferedReader(new FileReader(cosFile13));
              r14 = new BufferedReader(new FileReader(cosFile14));
               r15 = new BufferedReader(new FileReader(cosFile15));
             
           //r8 = new BufferedReader(new FileReader(cosFile8));
        //    r8 = new BufferedReader(new FileReader("D:/Price.txt")); 
       }catch(IOException e){
           e.printStackTrace();
       }
       }
     
     
     //.......................................................................................
             //Writing to the file\\
     public static void writeToFile(Movie m){
        if(cosFile1.canWrite()){
            try{
                 w1.write(m.getMovieName());
                 w1.newLine();
                 w1.write(m.getHallName());
                 w1.newLine();
                  w1.write(m.getTimeOfShow());
                 w1.newLine();
                 w1.write(""+m.getNoTickets());
                 w1.newLine();
                 w1.write(""+m.getChildTicketPrice());
                 w1.newLine();
                  w1.write(""+m.getAdultTicketPrice());
                 w1.newLine();
                 w1.write(m.getMovieDate());
               
                 w1.flush();
            }catch(IOException e){
                javax.swing.JOptionPane.showMessageDialog(null, "Writing to File Failed", null, javax.swing.JOptionPane.ERROR_MESSAGE, null);
            }
        }
    }
    public static void writeToFile(Hall h){
        if(cosFile4.canWrite()){
            try{
                 w4.write(""+h.getSeats_front());
                 w4.newLine();
                 w4.write(""+h.getSeats_middle());
                 w4.newLine();
                 w4.write(""+h.getSeats_back());
                 w4.newLine();
                 w4.flush();
            }catch(IOException e){
                javax.swing.JOptionPane.showMessageDialog(null, "Writing to File Failed", null, javax.swing.JOptionPane.ERROR_MESSAGE, null);
            }
        }
    }
    
    public static void writeToFile(Package p){
        if(cosFile5.canWrite()){
            try{
                 w5.write(p.getPackage_id());
                 w5.newLine();
                 w5.write(""+p.getDiscountPercent());
                 w5.newLine();
                 w5.write(""+p.getPackage_details());
                 w5.newLine();
                 w5.flush();
            }catch(IOException e){
                javax.swing.JOptionPane.showMessageDialog(null, "Writing to File Failed", null, javax.swing.JOptionPane.ERROR_MESSAGE, null);
            }
            }
    }
    
    public static void writeToFile(User u){
        if(cosFile2.canWrite()){
            try{
                 w2.write(u.getFirst_name());
                 w2.newLine();
                 w2.write(u.getLast_name());
                 w2.newLine();
                 w2.write(u.getUsername());
                 w2.newLine();
                 w2.write(u.getPassword());
                 w2.newLine(); 
                 w2.flush();
            }catch(IOException e){
                javax.swing.JOptionPane.showMessageDialog(null, "Writing to File Failed", null, javax.swing.JOptionPane.ERROR_MESSAGE, null);
            }
            }
    }
   /* public static void writeToFile(Admin a){
        if(cosFile6.canWrite()){
            try{
                 w6.write(a.getUsername());
                 w6.newLine();
                 w6.write(a.getPassword());
                 w6.newLine();
                 w6.write(a.getF_name());
                 w6.newLine();
                 w6.write(a.getL_name());
                 w6.newLine();
                 w6.flush();
            }catch(IOException e){
                javax.swing.JOptionPane.showMessageDialog(null, "Writing to File Failed", null, javax.swing.JOptionPane.ERROR_MESSAGE, null);
            }
            }
    }*/
   public static void writeToFile(Deals d){
        if(cosFile7.canWrite()){
            try{
               w7.write(d.getName());
               w7.newLine();
               w7.write(d.getSnack());
               w7.newLine();
               w7.write(d.getDrink());
               w7.newLine();
               w7.write(""+d.getDiscount());
               w7.newLine();
               w7.write(""+d.getPrice());
               w7.newLine();
               w7.flush();
            }catch(IOException e){
                javax.swing.JOptionPane.showMessageDialog(null, "Writing to File Failed", null, javax.swing.JOptionPane.ERROR_MESSAGE, null);
            }
        }
    }

     /*public static void writeToFile(Price p){ 
      if(cosFile8.canWrite()){
          try{
              w8.write(p.getTicket_cost());
              w8.write(p.getPopcorn_cost());
              w8.write(p.getBurger_cost());
              w8.write(p.getFries_cost());
              w8.write(p.getPepsi_cost());
              w8.write(p.getCocacola_cost());
              w8.write(p.getFanta_cost());
          }catch(IOException e){
              e.printStackTrace();
          }
      }   
     }*/      
        public static void writeToFile(Snack s){
        if(cosFile9.canWrite()){
            try{
                 w9.write(s.getSnack_name());
                 w9.newLine();
                 w9.write(""+s.getSnack_price());
                 w9.newLine();
                 w9.flush();
            }catch(IOException e){
                javax.swing.JOptionPane.showMessageDialog(null, "Writing to File Failed", null, javax.swing.JOptionPane.ERROR_MESSAGE, null);
            }
            }
    }
        public static void writeToFile(Drink d){
        if(cosFile10.canWrite()){
            try{
                 w10.write(d.getDrink_name());
                 w10.newLine();
                 w10.write(""+d.getDrink_price());
                 w10.newLine();
                 w10.flush();
            }catch(IOException e){
                javax.swing.JOptionPane.showMessageDialog(null, "Writing to File Failed", null, javax.swing.JOptionPane.ERROR_MESSAGE, null);
            }
            }
    }
        public static void writeToFile(Booking b){
        if(cosFile15.canWrite()){
            try{
                w15.write(b.getUsername());
                w15.newLine();
                 w15.write(b.getMovie_name());
                 w15.newLine();
                 w15.write(""+b.getChildtickets());
                 w15.newLine();
                  w15.write(""+b.getBill());
                 w15.newLine();
                 w15.write(b.getHall_name());
                 w15.newLine();
                  w15.write(b.getTime());
                 w15.newLine();
                 w15.write(""+b.getDate());
                 w15.newLine();
                 w15.write(b.getSnack());
                 w15.newLine();
                  w15.write(b.getDrink());
                 w15.newLine();
                 w15.write(b.getDeal());
                 w15.newLine();
                 w15.write(b.getPackage());
                 w15.newLine();
                
                 
              
                 w15.flush();
            }catch(IOException e){
                javax.swing.JOptionPane.showMessageDialog(null, "Writing to File Failed", null, javax.swing.JOptionPane.ERROR_MESSAGE, null);
            }
        }
    }
       //.................................................................................
                 //Creating arraylist to add read data
     public static ArrayList<Movie> readAll1(){
       ArrayList<Movie> list = new ArrayList<Movie>();
       Movie h =readItem1();
       while(h!=null){
           list.add(h);
           h =readItem1();
       }
      return list;
   }
   public static ArrayList<Hall> readAll4(){
       ArrayList<Hall> list = new ArrayList<Hall>();
       Hall h =readItem4();
       while(h!=null){
           list.add(h);
           h =readItem4();
       }
      return list;
   }
    public static ArrayList<Package> readAll5(){
       ArrayList<Package> list5 = new ArrayList<Package>();
       Package pack= readItem5();
      
       while(pack!=null){
           list5.add(pack);
          pack=readItem5();
       }
        return list5;
       }
     public static ArrayList<User> readAll2(){
       ArrayList<User> list2 = new ArrayList<User>();
       User a= readItem2();
       while(a!=null){
           list2.add(a);
          a=readItem2();
       }
        return list2;
    }
 /*   public static ArrayList<Admin> readAll6(){
       ArrayList<Admin> list6 = new ArrayList<Admin>();
       Admin a= readItem6();
       while(a!=null){
           list6.add(a);
          a=readItem6();
       }
        return list6;
    }*/
    
      public static ArrayList<Deals> readAll7(){
       ArrayList<Deals> list = new ArrayList<Deals>();
       Deals d=readItem7();
       while(d!=null){
           list.add(d);
           d =readItem7();
       }
      return list;
   }  
     /* public static ArrayList<Price> readAll8(){
          ArrayList<Price> list = new ArrayList<Price>();
          Price p = readItem8();
          while(p!=null){
              list.add(p);
              p = readItem8();
          }
          return list;
      }*/
           public static ArrayList<Snack> readAll9(){
       ArrayList<Snack> list = new ArrayList<Snack>();
       Snack snack =readItem9();
       while(snack!=null){
           list.add(snack);
           snack =readItem9();
       }
      return list;
   }
        public static ArrayList<Drink> readAll10(){
        ArrayList<Drink> list = new ArrayList<Drink>();
        Drink drink =readItem10();
        while(drink!=null){
           list.add(drink);
           drink =readItem10();
        }
       return list;
        }
        public static ArrayList<Booking> readAll15(){
       ArrayList<Booking> list = new ArrayList<Booking>();
       Booking b=readItem15();
       while(b!=null){
           list.add(b);
           b =readItem15();
       }
      return list;
   }
       //.........................................................................................
                  //Reading data from file
    
      public static Movie readItem1(){
         Movie m = null;
         try{
           if(r1.ready()){
                String n = r1.readLine();
                String hn = r1.readLine();
                String ti= r1.readLine();
                String t= r1.readLine();
                String ct= r1.readLine();
                String at= r1.readLine();
                String d =  r1.readLine();
                
                m =new Movie(n,hn,ti,Integer.parseInt(t),Integer.parseInt(ct),Integer.parseInt(at),d);
            } 
         
         }catch(IOException e){
             e.printStackTrace();
         }
         return m;
     } 
      public static User readItem2(){
        User u = null;
        try{
            if(r2.ready()){
            String fn= r2.readLine();
            String ln= r2.readLine();
            String un = r2.readLine();
            String pa= r2.readLine();
           
            
            u = new User(fn,ln,un,pa);
            }
        }catch(IOException e){
         e.printStackTrace();
        }
        return u;
        }
     public static Hall readItem4(){
         Hall h = null;
         try{
           if(r4.ready()){
                String front= r4.readLine();
                String middle =r4.readLine();
                String back = r4.readLine();
                String price = r4.readLine();
              h =new Hall(Integer.parseInt(front),Integer.parseInt(middle),Integer.parseInt(back));
            } 
         }catch(IOException e){
             e.printStackTrace();
         }
         return h;
     } 
        
    public static Package readItem5(){
        Package pack = null;
        try{
            if(r5.ready()){
            String id = r5.readLine();
            String discount = r5.readLine();
            String details= r5.readLine();
            
            pack = new Package(id,Integer.parseInt(discount),details);
            }
        }catch(IOException e){
         e.printStackTrace();
        }
        return pack;
        }
   /* public static Admin readItem6(){
        Admin a = null;
        try{
            if(r6.ready()){
            String un = r6.readLine();
            String pa= r6.readLine();
            String fn= r6.readLine();
            String ln= r6.readLine();
            
            a = new Admin(un,pa,fn,ln);
            }
        }catch(IOException e){
         e.printStackTrace();
        }
        return a;
        }*/
    public static Deals readItem7(){
        Deals d = null;
        try{
            if(r7.ready()){
            String name = r7.readLine();
            String snack= r7.readLine();
            String drink= r7.readLine();
            String discount= r7.readLine();
            String price= r7.readLine();
            
            d= new Deals(name,snack,drink,Integer.parseInt(discount),Integer.parseInt(price));
            }
        }catch(IOException e){
         e.printStackTrace();
        }
        return d;
        }
  /*  public static Price readItem8(){
        Price p = null;
        try{
            if(r8.ready()){
                String pop = r8.readLine();
                String b=r8.readLine();
                String pep=r8.readLine();
                String fan=r8.readLine();
                String fr=r8.readLine();
                String coc=r8.readLine();
               
                p=new Price(Integer.parseInt(pop),Integer.parseInt(b),Integer.parseInt(pep),Integer.parseInt(fan),Integer.parseInt(fr),Integer.parseInt(coc));
            }
        }catch(IOException e){
            e.printStackTrace();
        }
        return p;
    }
     public static Price getprice(){
        return price.get(0);
    }*/
     
     public static Snack readItem9(){
         Snack s = null;
         try{
           if(r9.ready()){
                String name = r9.readLine();
                String price= r9.readLine();
               
                
                s =new Snack(name,Integer.parseInt(price));
            } 
         }catch(IOException e){
             e.printStackTrace();
         }
         return s;
     } 
      public static Drink readItem10(){
         Drink d = null;
         try{
           if(r10.ready()){
                String name = r10.readLine();
                String price= r10.readLine();
               
                
                d =new Drink(name,Integer.parseInt(price));
            } 
         }catch(IOException e){
             e.printStackTrace();
         }
         return d;
     } 
      public static Booking readItem15(){
         Booking b= null;
         try{
           if(r15.ready()){
                String n = r15.readLine();
                String mn = r15.readLine();
                String ct = r15.readLine();
                String ad = r15.readLine();
                String bill= r15.readLine();
                String hn = r15.readLine();
                String t= r15.readLine();
                 String da =  r15.readLine();
                String s =  r15.readLine();
                String d =  r15.readLine();
                String de=  r15.readLine();
                String p =  r15.readLine();
                b =new Booking(n,mn,Integer.parseInt(t),ad,Integer.parseInt(bill),hn,t,Date.valueOf(da),s,d,de,p);
            } 
         }catch(IOException e){
             e.printStackTrace();
         }catch(NumberFormatException e){
             e.printStackTrace();
         }
         return b ;
     } 
    
}
