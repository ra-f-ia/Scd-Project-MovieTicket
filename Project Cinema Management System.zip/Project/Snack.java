/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

/**
 *
 * @author dell
 */
public class Snack {
    private String snack_name;
    private int snack_price;

    public Snack(String snack_name, int snack_price) {
        this.snack_name = snack_name;
        this.snack_price = snack_price;
    }

    public String getSnack_name() {
        return snack_name;
    }

    public void setSnack_name(String snack_name) {
        this.snack_name = snack_name;
    }

    public int getSnack_price() {
        return snack_price;
    }

    public void setSnack_price(int snack_price) {
        this.snack_price = snack_price;
    }

    @Override
    public String toString() {
        return snack_name;
    }
    

}