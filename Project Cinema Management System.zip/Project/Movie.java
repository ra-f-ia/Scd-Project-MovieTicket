/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

import java.util.Date;

/**
 *
 * @author dell
 */
public class Movie {
    private String movieName; 
    private String HallName;
    private String timeOfShow;
    private int noTickets;
    private int childTicketPrice;
    private int adultTicketPrice;
 // private String movieAddress;
    private String movieDate;

    public Movie(String movieName, String HallName, String timeOfShow, int noTickets, int childTicketPrice, int adultTicketPrice, String movieDate) {
        this.movieName = movieName;
        this.HallName = HallName;
        this.timeOfShow = timeOfShow;
        this.noTickets = noTickets;
        this.childTicketPrice = childTicketPrice;
        this.adultTicketPrice = adultTicketPrice;
        this.movieDate = movieDate;
    }

    public String getMovieDate() {
        return movieDate;
    }

    public void setMovieDate(String movieDate) {
        this.movieDate = movieDate;
    }

   
    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public int getNoTickets() {
        return noTickets;
    }

    public void setNoTickets(int noTickets) {
        this.noTickets = noTickets;
    }

    public int getChildTicketPrice() {
        return childTicketPrice;
    }

    public void setChildTicketPrice(int childTicketPrice) {
        this.childTicketPrice = childTicketPrice;
    }

    public int getAdultTicketPrice() {
        return adultTicketPrice;
    }

    public void setAdultTicketPrice(int adultTicketPrice) {
        this.adultTicketPrice = adultTicketPrice;
    }

    public String getHallName() {
        return HallName;
    }

    public void setHallName(String HallName) {
        this.HallName = HallName;
    }

    public String getTimeOfShow() {
        return timeOfShow;
    }

    public void setTimeOfShow(String timeOfShow) {
        this.timeOfShow = timeOfShow;
    }
    

   /* public String getMovieAddress() {
        return movieAddress;
    }

    public void setMovieAddress(String movieAddress) {
        this.movieAddress = movieAddress;
    }*/

    @Override
    public String toString() {
        return movieName;
    }

   
    
}
  

  