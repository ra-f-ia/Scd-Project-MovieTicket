/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

/**
 *
 * @author dell
 */
public class Package {
    private String package_id;
    private int discountPercent;
    private String package_details;

    public Package(String package_id, int discountPercent, String package_details) {
        this.package_id = package_id;
        this.discountPercent = discountPercent;
        this.package_details = package_details;
    }

    public String getPackage_details() {
        return package_details;
    }

    public void setPackage_details(String package_details) {
        this.package_details = package_details;
    }

   

    public String getPackage_id() {
        return package_id;
    }

    public void setPackage_id(String package_id) {
        this.package_id = package_id;
    }

    public int getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(int discountPercent) {
        this.discountPercent = discountPercent;
    }

    @Override
    public String toString() {
        return package_id;
    }
    
    
}
