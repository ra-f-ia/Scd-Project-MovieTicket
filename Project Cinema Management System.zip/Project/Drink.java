/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;


/**
 *
 * @author dell
 */
public class Drink {
private String drink_name;
private int drink_price;

    public Drink(String drink_name, int drink_price) {
        this.drink_name = drink_name;
        this.drink_price = drink_price;
    }

    public String getDrink_name() {
        return drink_name;
    }

    public void setDrink_name(String drink_name) {
        this.drink_name = drink_name;
    }

    public int getDrink_price() {
        return drink_price;
    }

    public void setDrink_price(int drink_price) {
        this.drink_price = drink_price;
    }

    @Override
    public String toString() {
        return drink_name ;
    }


    
  
}
