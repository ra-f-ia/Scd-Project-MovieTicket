/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

import java.util.Date;

/**
 *
 * @author dell
 */
public class Booking {
    private String Username;
    private String movie_name;
    private int childtickets;
    private String adultticket;
    private int bill;
    //private int seat_no;
    private String hall_name;
    private String time;
    private Date date;
    private String snack;
    private String drink;
    private String deal;
    private String Package;

    public Booking(String Username, String movie_name, int childtickets, String adultticket, int bill, String hall_name, String time, Date date, String snack, String drink, String deal, String Package) {
        this.Username = Username;
        this.movie_name = movie_name;
        this.childtickets = childtickets;
        this.adultticket = adultticket;
        this.bill = bill;
        this.hall_name = hall_name;
        this.time = time;
        this.date = date;
        this.snack = snack;
        this.drink = drink;
        this.deal = deal;
        this.Package = Package;
    }

    

    
 

   

    

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

   

    public String getMovie_name() {
        return movie_name;
    }

    public void setMovie_name(String movie_name) {
        this.movie_name = movie_name;
    }

    public int getChildtickets() {
        return childtickets;
    }

    public void setChildtickets(int childtickets) {
        this.childtickets = childtickets;
    }

    public String getAdultticket() {
        return adultticket;
    }

    public void setAdultticket(String adultticket) {
        this.adultticket = adultticket;
    }

   
    public String getSnack() {
        return snack;
    }

    public void setSnack(String snack) {
        this.snack = snack;
    }

    public String getDrink() {
        return drink;
    }

    public void setDrink(String drink) {
        this.drink = drink;
    }

    public String getDeal() {
        return deal;
    }

    public void setDeal(String deal) {
        this.deal = deal;
    }

    public int getBill() {
        return bill;
    }

    public void setBill(int bill) {
        this.bill = bill;
    }

  /*  public int getSeat_no() {
        return seat_no;
    }

    public void setSeat_no(int seat_no) {
        this.seat_no = seat_no;
    }*/

    public String getHall_name() {
        return hall_name;
    }

    public void setHall_name(String hall_name) {
        this.hall_name = hall_name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPackage() {
        return Package;
    }

    public void setPackage(String Package) {
        this.Package = Package;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return Username;
    }
    
    
}
