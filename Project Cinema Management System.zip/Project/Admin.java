/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

/**
 *
 * @author dell
 */
public class Admin {
    private String Username;
    private String Password;
    private String f_name;
    private String l_name;

    public Admin(String Username, String Password, String f_name, String l_name) {
        this.Username = Username;
        this.Password = Password;
        this.f_name = f_name;
        this.l_name = l_name;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getF_name() {
        return f_name;
    }

    public void setF_name(String f_name) {
        this.f_name = f_name;
    }

    public String getL_name() {
        return l_name;
    }

    public void setL_name(String l_name) {
        this.l_name = l_name;
    }

   /* @Override
    public String toString() {
        return f_name;
    }*/
    
    
}

